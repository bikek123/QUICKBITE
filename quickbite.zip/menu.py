menu = {
    1: {"name": "Spicy Chicken Curry", "price": 85},
    2: {"name": "Vegetable Biryani", "price": 75},
    3: {"name": "Chicken Adobo Rice", "price": 70},
    4: {"name": "Pork Siomai Rice", "price": 60},
    5: {"name": "Burger", "price": 45},
    6: {"name": "Iced Tea", "price": 25},
    7: {"name": "Bottled Water", "price": 15}
}

def display_menu():
    print("\n========== QUICKBITE MENU ==========")

    for number, item in menu.items():
        print(f"{number}. {item['name']} - P{item['price']}")