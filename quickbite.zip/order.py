from cart import cart, calculate_total, view_cart
from payment import select_payment
from status import track_order

def submit_order(student_name):

    if not cart:
        print("Your cart is empty!")
        return False

    view_cart()

    payment = select_payment()

    print("\nStudent:", student_name)
    print("Payment:", payment)

    # INPUT VALIDATION MODULE
    while True:

        confirm = input(
            "\nSubmit your order? (yes/no): "
        ).strip().lower()

        if confirm == "yes":

            total = calculate_total()

            print("\nOrder successfully submitted!")
            print("Total Amount: P{:.2f}".format(total))

            track_order()

            cart.clear()

            return True

        elif confirm == "no":

            print("\nOrder submission cancelled.")
            print("You can still modify your cart.")

            return False

        else:

            print("\nINVALID INPUT!")
            print("Please enter ONLY 'yes' or 'no'.")
            print("Please try again.")

