def track_order():
    print("\n========== ORDER STATUS ==========")

    print("[OK] Order Received")

    print("\nYour order is ready!")
    print("Please proceed to the canteen.")