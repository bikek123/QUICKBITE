
from menu import menu, display_menu

cart = []

def add_to_cart():
    display_menu()

    while True:
        try:
            choice = int(input("\nEnter item number (0 to finish): "))

            if choice == 0:
                break

            if choice not in menu:
                print("Invalid item number!")
                continue

            quantity = int(input("Enter quantity: "))

            if quantity <= 0:
                print("Invalid quantity!")
                continue

            found = False

            for item in cart:
                if item["number"] == choice:
                    item["quantity"] += quantity
                    found = True
                    break

            if not found:
                cart.append({
                    "number": choice,
                    "name": menu[choice]["name"],
                    "price": menu[choice]["price"],
                    "quantity": quantity
                })

            print("Item added successfully!")

        except ValueError:
            print("Please enter a valid number.")

def calculate_total():
    total = 0

    for item in cart:
        total += item["price"] * item["quantity"]

    return total

def view_cart():
    print("\n========== ORDER SUMMARY ==========")

    if not cart:
        print("Your cart is empty.")
        return

    for item in cart:
        subtotal = item["price"] * item["quantity"]

        print(
            item["name"],
            "x", item["quantity"],
            "= P", subtotal
        )

    print("-----------------------------------")
    print("TOTAL: P", calculate_total())