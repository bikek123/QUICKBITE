
from menu import display_menu
from cart import add_to_cart, view_cart
from order import submit_order

def main():

    print("================================")
    print("      WELCOME TO QUICKBITE"      )
    print("   SMART CANTEEN PRE-ORDERING"   )
    print("================================")

    student_name = input("\nEnter your name: ")

    while True:

        print("\n========== MAIN MENU ==========")
        print("[1] View Food Menu")
        print("[2] Add Items to Cart")
        print("[3] View Order Summary")
        print("[4] Checkout")
        print("[5] Exit")

        try:
            choice = int(input("\nEnter your choice: "))

            if choice == 1:
                display_menu()

            elif choice == 2:
                add_to_cart()

            elif choice == 3:
                view_cart()

            elif choice == 4:
                if submit_order(student_name):
                    break

            elif choice == 5:
                print("Thank you for using Quickbite!")
                break

            else:
                print("Invalid choice!")

        except ValueError:
            print("Please enter a valid number.")

    print("\nSystem closed.")

if __name__ == "__main__":
    main()
