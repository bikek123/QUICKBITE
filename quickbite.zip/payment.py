def select_payment():
    print("\n========== PAYMENT ==========")
    print("[1] Cash (Pay at Pickup)")
    print("[2] E-Payment")

    while True:
        try:
            choice = int(input("Select payment: "))

            if choice == 1:
                return "Cash"

            elif choice == 2:
                return "E-Payment"

            else:
                print("Invalid choice!")

        except ValueError:
            print("Enter a valid number.")